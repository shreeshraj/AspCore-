﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace CoreProject.Migrations
{
    public partial class MyFirstMigrationl : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
